package com.example.budgetpal;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

public class DbConn extends SQLiteOpenHelper {

    // creating a constant variables for our database.
    // below variable is for our database name.
    private static final String DB_NAME = "budgetpal";

    // below int is our database version
    private static final int DB_VERSION = 6;

    // below variable is for  table name.
    private static final String cTABLE_NAME = "categories";
    // below variable is for columns.
    private static final String cID_COL = "cId";
    private static final String cNAME_COL = "cName";
    private static final String cDESCRIPTION_COL = "cDescription";
    private static final String cTYPE_COL = "cType";
    private static final String cBUDGET_COL = "cBudget";

    // below variable is for  table name.
    private static final String tTABLE_NAME = "transactions";
    // below variable is for columns.
    private static final String tID_COL = "tId";
    private static final String tCATEGORY_COL = "tCategory";
    private static final String tDATE_COL = "tDate";
    private static final String tDESCRIPTION_COL = "tDescription";
    private static final String tRECURRING_COL = "tRecurring";
    private static final String tPRICE_COL = "tPrice";

    // below variable is for  table name.
    private static final String totTABLE_NAME = "totalcalculations";
    // below variable is for columns.
    private static final String totID_COL = "totId";
    private static final String totCREDIT_COL = "totCredit";
    private static final String totDEBIT_COL = "totDebit";
    private static final String totBALANCE_COL = "totBalance";

    // creating a constructor for our database handler.
    public DbConn(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    // below method is for creating a database by running a sqlite query
    @Override
    public void onCreate(SQLiteDatabase db) {
        // on below line we are creating
        // an sqlite query and we are
        // setting our column names
        // along with their data types.
        String cQuery = "CREATE TABLE " + cTABLE_NAME + " ("
                + cID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + cNAME_COL + " TEXT,"
                + cDESCRIPTION_COL + " TEXT,"
                + cTYPE_COL + " TEXT,"
                + cBUDGET_COL + " DOUBLE)";

        String tQuery = "CREATE TABLE " + tTABLE_NAME + " ("
                + tID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + tCATEGORY_COL + " TEXT,"
                + tDATE_COL + " TEXT,"
                + tDESCRIPTION_COL + " TEXT,"
                + tRECURRING_COL + " TEXT,"
                + tPRICE_COL + " DOUBLE)";

        String totalCalculationQuery = "CREATE TABLE " + totTABLE_NAME + " ("
                + totID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + totCREDIT_COL + " DOUBLE,"
                + totDEBIT_COL + " DOUBLE,"
                + totBALANCE_COL + " DOUBLE)";

        // at last we are calling a exec sql
        // method to execute above sql query
        db.execSQL(cQuery);
        db.execSQL(tQuery);
        db.execSQL(totalCalculationQuery);

    }

    public void addSampleCategoryData() {

        // on below line we are creating a variable for
        // our sqlite database and calling writable method
        // as we are writing data in our database.
        SQLiteDatabase db = this.getWritableDatabase();

        // on below line we are creating a
        // variable for content values.
        ContentValues values = new ContentValues();

        // on below line we are passing all values
        // along with its key and value pair.
        values.put(cNAME_COL, "Salary");
        values.put(cDESCRIPTION_COL, "Monthly Category");
        values.put(cTYPE_COL, "Credit");
        values.put(cBUDGET_COL, 0.0);

        db.insert(cTABLE_NAME, null, values);

        values = new ContentValues();

        values.put(cNAME_COL, "Shopping");
        values.put(cDESCRIPTION_COL, "Shopping Category");
        values.put(cTYPE_COL, "Debit");
        values.put(cBUDGET_COL, 10000.0);

        db.insert(cTABLE_NAME, null, values);

        values = new ContentValues();

        values.put(cNAME_COL, "Utility bill");
        values.put(cDESCRIPTION_COL, "Utility billing  Category");
        values.put(cTYPE_COL, "Debit");
        values.put(cBUDGET_COL, 10000.0);

        // after adding all values we are passing
        // content values to our table.
        db.insert(cTABLE_NAME, null, values);

        // at last we are closing our
        // database after adding database.
        db.close();
    }

    // this method is use to add new to sqlite database tables.
    public void addNewCategory(String catName, String catDescription, String catType, double catBudget) {

        // on below line we are creating a variable for
        // our sqlite database and calling writable method
        // as we are writing data in our database.
        SQLiteDatabase db = this.getWritableDatabase();

        // on below line we are creating a
        // variable for content values.
        ContentValues values = new ContentValues();

        // on below line we are passing all values
        // along with its key and value pair.
        values.put(cNAME_COL, catName);
        values.put(cDESCRIPTION_COL, catDescription);
        values.put(cTYPE_COL, catType);
        values.put(cBUDGET_COL, catBudget);

        // after adding all values we are passing
        // content values to our table.
        db.insert(cTABLE_NAME, null, values);

        // at last we are closing our
        // database after adding database.
        db.close();
    }

    public void addNewTransaction(String tranCategory, String tranDate, String tranDescription, String tranRecurring, double transPrice) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(tCATEGORY_COL, tranCategory);
        values.put(tDATE_COL, tranDate);
        values.put(tDESCRIPTION_COL, tranDescription);
        values.put(tRECURRING_COL, tranRecurring);
        values.put(tPRICE_COL, transPrice);

        db.insert(tTABLE_NAME, null, values);

        Cursor cursorCategoryType = db.rawQuery("SELECT cType FROM " + cTABLE_NAME + " WHERE cName = '"+tranCategory+"'", null);
        ArrayList<DataModel> transactionModalArrayList = new ArrayList<>();
        String catType = "";

        if (cursorCategoryType.moveToFirst()) {
            do {
                // on below line we are adding the data from cursor to our array list.
                //cursorTransactionsCredit.add(new DataModel(cursorTransactionsCredit.getInt(0)));
                catType = cursorCategoryType.getString(cursorCategoryType.getColumnIndex("cType"));
            } while (cursorCategoryType.moveToNext());
            // moving our cursor to next.
        }
        cursorCategoryType.close();

        updateTotalCalculations(catType, transPrice);

        db.close();
    }

    // below is the method for updating categories
    public void updateCategory(int catId, String catName, String catDescription, String catType, double catBudget) {

        // calling a method to get writable database.
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        // on below line we are passing all values
        // along with its key and value pair.
        values.put(cNAME_COL, catName);
        values.put(cDESCRIPTION_COL, catDescription);
        values.put(cTYPE_COL, catType);
        values.put(cBUDGET_COL, catBudget);

        // on below line we are calling a update method to update our database and passing our values.
        // and we are comparing it with name of our course which is stored in original name variable.
        db.update(cTABLE_NAME, values, "cId=?", new String[]{String.valueOf(catId)});
        db.close();
    }

    public void updateTransaction(int tId, String tranCategory, String tranDate, String tranDescription, String tranRecurring, double transPrice) {

        // calling a method to get writable database.
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        // on below line we are passing all values
        // along with its key and value pair.
        values.put(tCATEGORY_COL, tranCategory);
        values.put(tDATE_COL, tranDate);
        values.put(tDESCRIPTION_COL, tranDescription);
        values.put(tRECURRING_COL, tranRecurring);
        values.put(tPRICE_COL, transPrice);

        // on below line we are calling a update method to update our database and passing our values.
        // and we are comparing it with name of our course which is stored in original name variable.
        db.update(tTABLE_NAME, values, "tId=?", new String[]{String.valueOf(tId)});
        db.close();
    }

    public void updateTotalCalculations(String type, double transPrice) {

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursorCalculations = db.rawQuery("SELECT totCredit AS Credit, totDebit AS Debit, totBalance AS Balance FROM " + totTABLE_NAME + " WHERE totId = '" + 1 + "'", null);
        ArrayList<DataModel> categoryModalArrayList = new ArrayList<>();
        double totCredit = 0.0;
        double totDebit = 0.0;
        double totBalance = 0.0;
        if (cursorCalculations.moveToFirst()) {
            do {
                totCredit = cursorCalculations.getDouble(cursorCalculations.getColumnIndex("Credit"));
                totDebit = cursorCalculations.getDouble(cursorCalculations.getColumnIndex("Debit"));
                totBalance = cursorCalculations.getDouble(cursorCalculations.getColumnIndex("Balance"));
            } while (cursorCalculations.moveToNext());

        }
        cursorCalculations.close();

        ContentValues values = new ContentValues();

        // on below line we are passing all values
        // along with its key and value pair.
        if(type.equals("Credit")){
            totCredit = totCredit + transPrice;
            totBalance = totBalance + transPrice;
        }else if(type.equals("Debit")){
            totDebit = totDebit + transPrice;
            totBalance = totBalance - transPrice;
        }

        values.put(totCREDIT_COL, totCredit);
        values.put(totDEBIT_COL, totDebit);
        values.put(totBALANCE_COL, totBalance);


        // on below line we are calling a update method to update our database and passing our values.
        // and we are comparing it with name of our course which is stored in original name variable.
        try{
            if (db.update(totTABLE_NAME, values, "totId=?", new String[]{String.valueOf(1)}) == 0){
                db.insert(totTABLE_NAME, null, values);
                Log.i("TOTCAL_Inserted", totBalance +"--"+ totBalance +"--"+ transPrice);
            }
            /*else{
                Log.i("TOTCAL_Updated", totBalance +"--"+ totBalance +"--"+ transPrice);
            }*/
            //int a = db.update(totTABLE_NAME, values, "totId=?", new String[]{String.valueOf(1)});
            //Log.i("TOTCAL1", totBalance +"--"+ totBalance +"--"+ transPrice);
        }catch (Exception e){
            db.insert(totTABLE_NAME, null, values);
            //Log.i("TOTCAL2", totBalance +"--"+ totBalance +"--"+ transPrice);
        }

        db.close();
    }

    // we have created a new method for reading all the courses.
    public ArrayList<DataModel> readCategories() {
        // on below line we are creating a
        // database for reading our database.
        SQLiteDatabase db = this.getReadableDatabase();

        // on below line we are creating a cursor with query to read data from database.
        Cursor cursorCategories = db.rawQuery("SELECT * FROM " + cTABLE_NAME, null);

        // on below line we are creating a new array list.
        ArrayList<DataModel> categoryModalArrayList = new ArrayList<>();

        // moving our cursor to first position.
        if (cursorCategories.moveToFirst()) {
            do {
                // on below line we are adding the data from cursor to our array list.
                categoryModalArrayList.add(new DataModel(cursorCategories.getInt(0),
                        cursorCategories.getString(1),
                        cursorCategories.getString(2),
                        cursorCategories.getString(3),
                        cursorCategories.getDouble(4)));
            } while (cursorCategories.moveToNext());
            // moving our cursor to next.
        }
        // at last closing our cursor
        // and returning our array list.
        cursorCategories.close();
        return categoryModalArrayList;
    }

    public ArrayList<DataModel> readTransactions() {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursorTransactions = db.rawQuery("SELECT * FROM " + tTABLE_NAME + " ORDER BY tId DESC", null);

        ArrayList<DataModel> transactionModalArrayList = new ArrayList<>();

        if (cursorTransactions.moveToFirst()) {
            do {
                transactionModalArrayList.add(new DataModel(cursorTransactions.getInt(0),
                        cursorTransactions.getString(1),
                        cursorTransactions.getString(2),
                        cursorTransactions.getString(3),
                        cursorTransactions.getString(4),
                        cursorTransactions.getDouble(5),
                        readAndCheckDebitCategory(cursorTransactions.getString(1))));
                Log.i("TrType", readAndCheckDebitCategory(cursorTransactions.getString(1)));

            } while (cursorTransactions.moveToNext());
        }
        cursorTransactions.close();
        return transactionModalArrayList;
    }

    public ArrayList<DataModel> readDebitCategories() {
        // on below line we are creating a
        // database for reading our database.
        SQLiteDatabase db = this.getReadableDatabase();

        // on below line we are creating a cursor with query to read data from database.
        Cursor cursorCategories = db.rawQuery("SELECT * FROM " + cTABLE_NAME + " WHERE cType = 'Debit'", null);

        // on below line we are creating a new array list.
        ArrayList<DataModel> categoryModalArrayList = new ArrayList<>();

        // moving our cursor to first position.
        if (cursorCategories.moveToFirst()) {
            do {
                // on below line we are adding the data from cursor to our array list.
                categoryModalArrayList.add(new DataModel(cursorCategories.getInt(0),
                        cursorCategories.getString(1),
                        cursorCategories.getString(2),
                        cursorCategories.getString(3),
                        cursorCategories.getDouble(4)));
            } while (cursorCategories.moveToNext());
            // moving our cursor to next.
        }
        // at last closing our cursor
        // and returning our array list.
        cursorCategories.close();
        return categoryModalArrayList;
    }

    public ArrayList<DataModel> readCategoryNamesForSpinner() {
        // on below line we are creating a
        // database for reading our database.
        SQLiteDatabase db = this.getReadableDatabase();

        // on below line we are creating a cursor with query to read data from database.
        Cursor cursorCategories = db.rawQuery("SELECT cId, cName FROM " + cTABLE_NAME, null);

        // on below line we are creating a new array list.
        ArrayList<DataModel> categoryModalArrayList = new ArrayList<>();

        // moving our cursor to first position.
        if (cursorCategories.moveToFirst()) {
            do {
                // on below line we are adding the data from cursor to our array list.
                categoryModalArrayList.add(new DataModel(cursorCategories.getInt(0),
                        cursorCategories.getString(1)));
            } while (cursorCategories.moveToNext());
            // moving our cursor to next.
        }
        // at last closing our cursor
        // and returning our array list.
        cursorCategories.close();
        return categoryModalArrayList;
    }

    public double readTransactionCostPerCategory(String tCategory) {
        // on below line we are creating a
        // database for reading our database.
        SQLiteDatabase db = this.getReadableDatabase();

        // on below line we are creating a cursor with query to read data from database.
        Cursor cursorCategories = db.rawQuery("SELECT SUM(tPrice) AS Sum FROM " + tTABLE_NAME + " WHERE tCategory = '" + tCategory + "'", null);

        // on below line we are creating a new array list.
        ArrayList<DataModel> categoryModalArrayList = new ArrayList<>();
        //int cost = cursorCategories.getColumnIndex("tPrice");
        //double cost2 = cursorCategories.getDouble(-1);
        double cost = 0.0;

        // moving our cursor to first position.
        if (cursorCategories.moveToFirst()) {
            do {
                // on below line we are adding the data from cursor to our array list.
                //categoryModalArrayList.add(new DataModel(cursorCategories.getInt(0)));
                cost = cursorCategories.getDouble(cursorCategories.getColumnIndex("Sum"));
            } while (cursorCategories.moveToNext());
            // moving our cursor to next.
        }
        // at last closing our cursor
        // and returning our array list.
        cursorCategories.close();
        Log.i("COLUMN", String.valueOf(cost));
        return cost;
    }

    public String readAndCheckDebitCategory(String cName) {
        // on below line we are creating a
        // database for reading our database.
        SQLiteDatabase db = this.getReadableDatabase();

        // on below line we are creating a cursor with query to read data from database.
        Cursor cursorCategories = db.rawQuery("SELECT cType FROM " + cTABLE_NAME + " WHERE cName = '" + cName + "'", null);

        // on below line we are creating a new array list.
        ArrayList<DataModel> categoryModalArrayList = new ArrayList<>();
        //int cost = cursorCategories.getColumnIndex("tPrice");
        //double cost2 = cursorCategories.getDouble(-1);
        String type = "";

        // moving our cursor to first position.
        if (cursorCategories.moveToFirst()) {
            do {
                // on below line we are adding the data from cursor to our array list.
                //categoryModalArrayList.add(new DataModel(cursorCategories.getInt(0)));
                type = cursorCategories.getString(cursorCategories.getColumnIndex("cType"));
            } while (cursorCategories.moveToNext());
            // moving our cursor to next.
        }
        // at last closing our cursor
        // and returning our array list.
        cursorCategories.close();

        //Log.i("TrType", type);

        return type;
    }

    public double readBudgetPerCategory(String cName) {
        // on below line we are creating a
        // database for reading our database.
        SQLiteDatabase db = this.getReadableDatabase();

        // on below line we are creating a cursor with query to read data from database.
        Cursor cursorCategories = db.rawQuery("SELECT cBudget FROM " + cTABLE_NAME + " WHERE cName = '" + cName + "'", null);

        // on below line we are creating a new array list.
        ArrayList<DataModel> categoryModalArrayList = new ArrayList<>();
        //int cost = cursorCategories.getColumnIndex("tPrice");
        //double cost2 = cursorCategories.getDouble(-1);
        double budget = 0.0;

        // moving our cursor to first position.
        if (cursorCategories.moveToFirst()) {
            do {
                // on below line we are adding the data from cursor to our array list.
                //categoryModalArrayList.add(new DataModel(cursorCategories.getInt(0)));
                budget = cursorCategories.getDouble(cursorCategories.getColumnIndex("cBudget"));
            } while (cursorCategories.moveToNext());
            // moving our cursor to next.
        }
        // at last closing our cursor
        // and returning our array list.
        cursorCategories.close();
        Log.i("COLUMN", String.valueOf(budget));
        return budget;
    }

    public double readLeftBudgetForNewCategory() {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursorTransactionsCredit = db.rawQuery("SELECT SUM(t.tPrice) as Sum FROM " + tTABLE_NAME + " t, " + cTABLE_NAME + " c WHERE t.tCategory = c.cName AND c.cType = 'Credit'", null);
        Cursor cursorTransactionsDebit = db.rawQuery("SELECT SUM(cBudget) as Sum FROM " + cTABLE_NAME + " WHERE cType = 'Debit'", null);

        ArrayList<DataModel> transactionModalArrayList = new ArrayList<>();

        double credit = 0.0;
        double debit = 0.0;
        double left = 0.0;

        if (cursorTransactionsCredit.moveToFirst()) {
            do {
                // on below line we are adding the data from cursor to our array list.
                //cursorTransactionsCredit.add(new DataModel(cursorTransactionsCredit.getInt(0)));
                credit = cursorTransactionsCredit.getDouble(cursorTransactionsCredit.getColumnIndex("Sum"));
            } while (cursorTransactionsCredit.moveToNext());
            // moving our cursor to next.
        }

        if (cursorTransactionsDebit.moveToFirst()) {
            do {
                // on below line we are adding the data from cursor to our array list.
                //cursorTransactionsCredit.add(new DataModel(cursorTransactionsCredit.getInt(0)));
                debit = cursorTransactionsDebit.getDouble(cursorTransactionsDebit.getColumnIndex("Sum"));
            } while (cursorTransactionsDebit.moveToNext());
            // moving our cursor to next.
        }

        left = credit - debit;

        Log.i("LEFTBUDGEST", left+"--"+credit+"--"+debit);

        // at last closing our cursor
        // and returning our array list.
        cursorTransactionsCredit.close();
        return left;
    }

    public double readTotalBalance() {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursorCalculations = db.rawQuery("SELECT totBalance AS Balance FROM " + totTABLE_NAME + " WHERE totId = '" + 1 + "'", null);
        ArrayList<DataModel> categoryModalArrayList = new ArrayList<>();
        double totBalance = 0.0;
        if (cursorCalculations.moveToFirst()) {
            do {
                totBalance = cursorCalculations.getDouble(cursorCalculations.getColumnIndex("Balance"));
            } while (cursorCalculations.moveToNext());

        }
        cursorCalculations.close();

        db.close();
        Log.i("TOTBAL", String.valueOf(totBalance));

        return totBalance;
    }

    public ArrayList<DataModel> readTotalCalculations() {
        // on below line we are creating a
        // database for reading our database.
        SQLiteDatabase db = this.getReadableDatabase();

        // on below line we are creating a cursor with query to read data from database.
        Cursor cursorCalculations = db.rawQuery("SELECT * FROM " + totTABLE_NAME, null);

        // on below line we are creating a new array list.
        ArrayList<DataModel> categoryModalArrayList = new ArrayList<>();

        // moving our cursor to first position.
        if (cursorCalculations.moveToFirst()) {
            do {
                // on below line we are adding the data from cursor to our array list.
                categoryModalArrayList.add(new DataModel(cursorCalculations.getInt(0),
                        cursorCalculations.getDouble(1),
                        cursorCalculations.getDouble(2),
                        cursorCalculations.getDouble(3)));
            } while (cursorCalculations.moveToNext());
            // moving our cursor to next.
        }
        // at last closing our cursor
        // and returning our array list.
        cursorCalculations.close();
        return categoryModalArrayList;
    }

    public double readTotalBudgetAnalysis() {
        // on below line we are creating a
        // database for reading our database.
        SQLiteDatabase db = this.getReadableDatabase();

        // on below line we are creating a cursor with query to read data from database.
        Cursor cursorBudgetOverall = db.rawQuery("SELECT SUM(cBudget) as Sum FROM " + cTABLE_NAME + " WHERE cType = 'Debit'", null);

        double budgetTotal = 0.0;

        if (cursorBudgetOverall.moveToFirst()) {
            do {
                // on below line we are adding the data from cursor to our array list.
                //cursorTransactionsCredit.add(new DataModel(cursorTransactionsCredit.getInt(0)));
                budgetTotal = cursorBudgetOverall.getDouble(cursorBudgetOverall.getColumnIndex("Sum"));
            } while (cursorBudgetOverall.moveToNext());
            // moving our cursor to next.
        }

        return budgetTotal;
    }

    // below is the method for deleting our category.
    public void deleteCategory(String categoryId) {

        // on below line we are creating
        // a variable to write our database.
        SQLiteDatabase db = this.getWritableDatabase();

        // on below line we are calling a method to delete our
        // course and we are comparing it with our course name.
        db.delete(cTABLE_NAME, "cId=?", new String[]{categoryId});
        db.close();
    }

    public void deleteTransaction(String transactionId) {

        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(tTABLE_NAME, "tId=?", new String[]{transactionId});
        db.close();
    }




    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // this method is called to check if the table exists already.
        db.execSQL("DROP TABLE IF EXISTS " + cTABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + tTABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + totTABLE_NAME);
        onCreate(db);
    }

}
