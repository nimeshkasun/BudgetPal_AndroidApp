package com.example.budgetpal;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.anychart.anychart.AnyChart;
import com.anychart.anychart.AnyChartView;
import com.anychart.anychart.DataEntry;
import com.anychart.anychart.Pie;
import com.anychart.anychart.ValueDataEntry;
import com.example.budgetpal.categories.Categories;
import com.example.budgetpal.transactions.Transactions;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private Button transactions;
    private Button categories;
    private TextView currentBalance;

    ArrayList<DataModel> recordsList, recordsListCatNames, totalCalculations, totalBudgetCalculations;
    private DbConn dbConn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.summary);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.summary:
                        return true;
                    case R.id.transactions:
                        startActivity(new Intent(getApplicationContext()
                                , Transactions.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.categories:
                        startActivity(new Intent(getApplicationContext()
                                , Categories.class));
                        overridePendingTransition(0, 0);
                        return true;
                }
                return false;
            }
        });

        /*transactions = findViewById(R.id.btnTransactions);
        transactions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent intent = new Intent(MainActivity.this, Transactions.class);
                startActivity(intent);
            }
        });

        categories = findViewById(R.id.btnCategories);
        categories.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                Intent intent = new Intent(MainActivity.this, Categories.class);
                startActivity(intent);
            }
        });*/

        totalCalculations = new ArrayList<>();
        dbConn = new DbConn(MainActivity.this);
        //double totalCalculations = dbConn.readTotalCalculations();
        //ArrayList<String> categoryNames = new ArrayList<>();
        //List<DataEntry> data = new ArrayList<>();

        /*for(int i=0; i<totalCalculations.size(); i++) {
            DataModel modalCatNames = totalCalculations.get(i);
            //categoryNames.add(modalCatNames.getCatName());

            recordsList = new ArrayList<>();
            double cost = dbConn.readTransactionCostPerCategory(modalCatNames.getCatName());
            data.add(new ValueDataEntry(modalCatNames.getCatName(), cost));
        }*/

        //Set Available Balance
        double totBalance = dbConn.readTotalBalance();
        //double totBalance = 0.0;
        currentBalance = findViewById(R.id.currentBalance);
        currentBalance.setText("Balance: " + String.valueOf(totBalance));
        //currentBalance.setText("ss");

        double totalSpending = 0.0;
        //Overall Summary Chart
        totalCalculations = new ArrayList<>();
        dbConn = new DbConn(MainActivity.this);
        totalCalculations = dbConn.readTotalCalculations();
        //ArrayList<String> categoryNames = new ArrayList<>();
        List<DataEntry> dataOverall = new ArrayList<>();

        for (int i = 0; i < totalCalculations.size(); i++) {
            DataModel modalCalculations = totalCalculations.get(i);
            //categoryNames.add(modalCatNames.getCatName());

            recordsList = new ArrayList<>();
            TextView totalCredit = findViewById(R.id.totalCredit);
            totalCredit.setText("Total Credit: " + modalCalculations.getTotCredit());
            TextView totalDebit = findViewById(R.id.totalDebit);
            totalDebit.setText("Total Debit: " + modalCalculations.getTotDebit());
            totalSpending = modalCalculations.getTotCredit();

            /*dataOverall.add(new ValueDataEntry("Total Credit", modalCalculations.getTotCredit()));

            dataOverall.add(new ValueDataEntry("Total Debit", modalCalculations.getTotDebit()));*/
        }
        /*AnyChartView anyChartViewOverall = findViewById(R.id.overallSummary);
        Pie pieOverall = AnyChart.pie();
        pieOverall.data(dataOverall);
        anyChartViewOverall.setChart(pieOverall);*/


        //
        //
        // Overall Budget Summary Chart
        //
        //
        //totalBudgetCalculations = new ArrayList<>();
        dbConn = new DbConn(MainActivity.this);
        double totalBudgetOverall = dbConn.readTotalBudgetAnalysis();
        //ArrayList<String> categoryNames = new ArrayList<>();
        List<DataEntry> dataBudgetOverall = new ArrayList<>();

        dataBudgetOverall.add(new ValueDataEntry("Total Spending", totalSpending));
        dataBudgetOverall.add(new ValueDataEntry("Total Budget", totalBudgetOverall));

        Log.i("BUGETSUM", totalSpending + "--" + totalBudgetOverall);

        AnyChartView anyChartViewBudgetOverall = findViewById(R.id.overallBudgetSummary);
        Pie pieBudgetOverall = AnyChart.pie();
        pieBudgetOverall.data(dataBudgetOverall);
        anyChartViewBudgetOverall.setChart(pieBudgetOverall);


        //
        //
        // Category wise data
        //
        //
        recordsListCatNames = new ArrayList<>();
        dbConn = new DbConn(MainActivity.this);
        recordsListCatNames = dbConn.readDebitCategories();
        //ArrayList<String> categoryNames = new ArrayList<>();
        //List<DataEntry> data = new ArrayList<>();

       /* TextView catSummaryDataName = findViewById(R.id.catSummaryDataName);
        TextView catSummaryDataBudget = findViewById(R.id.catSummaryDataBudget);
        TextView catSummaryDataSpending = findViewById(R.id.catSummaryDataSpending);*/

        /*catSummaryDataName.append("/n");
        catSummaryDataBudget.append("/n");
        catSummaryDataSpending.append("/n");*/

        // get a reference for the TableLayout
        TableLayout table = (TableLayout) findViewById(R.id.TableLayout);


        for (int i = 0; i < recordsListCatNames.size(); i++) {
            DataModel modalCatNames = recordsListCatNames.get(i);
            //categoryNames.add(modalCatNames.getCatName());

            recordsList = new ArrayList<>();
            double cost = dbConn.readTransactionCostPerCategory(modalCatNames.getCatName());
            double budget = dbConn.readBudgetPerCategory(modalCatNames.getCatName());
            //data.add(new ValueDataEntry(modalCatNames.getCatName(), cost));

            Log.i("CATSUM", modalCatNames.getCatName() + "--" + budget + "--" + cost);
            //catSummaryDataName.setText(modalCatNames.getCatName());
            /*catSummaryDataName.append("\n" + modalCatNames.getCatName());
            catSummaryDataBudget.append("\n" + String.valueOf(budget));
            catSummaryDataSpending.append("\n" + String.valueOf(cost));*/

            //for (int j=0; j < 1; j++) {

            DisplayMetrics metrics = Resources.getSystem().getDisplayMetrics();
            float px;

            TableRow row = new TableRow(MainActivity.this);

            TextView c = new TextView(MainActivity.this);
            px = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 170, getResources().getDisplayMetrics());
            c.setWidth(Math.round(px));
            Log.i("PIX1", String.valueOf(px) +"-" +  String.valueOf(Math.round(px)));
            c.setText(String.valueOf(modalCatNames.getCatName()));

            TextView b = new TextView(MainActivity.this);
            px = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 100, getResources().getDisplayMetrics());
            b.setWidth(Math.round(px));
            Log.i("PIX2", String.valueOf(px) +"-" +  String.valueOf(Math.round(px)));
            b.setText(String.valueOf(budget));

            TextView s = new TextView(MainActivity.this);
            px = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 100, getResources().getDisplayMetrics());
            s.setWidth(Math.round(px));
            Log.i("PIX3", String.valueOf(px) + "-" + String.valueOf(Math.round(px)));
            s.setText(String.valueOf(cost));

            row.addView(c);
            row.addView(b);
            row.addView(s);
            //}


            //table.removeView(View );
            table.removeView(row);
            //table.setWeightSum(1.0f);
            table.addView(row, new TableLayout.LayoutParams(TableLayout.LayoutParams.MATCH_PARENT, TableLayout.LayoutParams.WRAP_CONTENT));

        }

        /*AnyChartView anyChartView = findViewById(R.id.any_chart_view);
        Pie pie = AnyChart.pie();

        pie.data(data);
        anyChartView.setChart(pie);*/


    }
}